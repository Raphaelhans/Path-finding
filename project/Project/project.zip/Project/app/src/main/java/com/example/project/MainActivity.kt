package com.example.project

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.project.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var graph: Map<String, List<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Define the graph (nodes and edges)
        graph = mapOf(
            "1" to listOf("2", "4"),
            "2" to listOf("1", "3", "5"),
            "3" to listOf("2", "13"),
            "4" to listOf("1", "6"),
            "5" to listOf("2", "7"),
            "6" to listOf("4", "8"),
            "7" to listOf("5", "6", "9", "12"),
            "8" to listOf("6", "10", "15"),
            "9" to listOf("7", "11", "12"),
            "10" to listOf("8", "11", "14", "15"),
            "11" to listOf("9", "10", "16"),
            "12" to listOf("7", "9", "13"),
            "13" to listOf("3", "12", "28", "34"),
            "14" to listOf("10", "20", "79"),
            "15" to listOf("8", "10", "21"),
            "16" to listOf("11", "18", "21"),
            "17" to listOf("19", "20", "28"),
            "18" to listOf("16", "19", "24", "35"),
            "19" to listOf("18", "17", "26"),
            "20" to listOf("14", "17", "21"),
            "21" to listOf("15", "16", "20", "22"),
            "22" to listOf("21", "25"),
            "23" to listOf("26", "27"),
            "24" to listOf("18", "25", "27"),
            "25" to listOf("22", "24", "26"),
            "26" to listOf("19", "25", "23"),
            "27" to listOf("24", "23", "28"),
            "28" to listOf("13", "17", "27", "29"),
            "29" to listOf("28", "30"),
            "30" to listOf("29", "31", "33"),
            "31" to listOf("30", "32", "78", "82"),
            "32" to listOf("31", "33"),
            "33" to listOf("32", "30", "81"),
            "34" to listOf("13", "35"),
            "35" to listOf("34", "18"),
            "36" to listOf("37", "80"),
            "37" to listOf("36", "38", "41"),
            "38" to listOf("37", "39", "42"),
            "39" to listOf("38", "40", "43"),
            "40" to listOf("39", "44", "81"),
            "41" to listOf("37", "42"),
            "42" to listOf("38", "41", "43"),
            "43" to listOf("39", "42", "44"),
            "44" to listOf("40", "43", "45"),
            "45" to listOf("44", "46"),
            "46" to listOf("45", "47", "49"),
            "47" to listOf("46", "48"),
            "48" to listOf("47", "49", "58"),
            "49" to listOf("46", "48", "50"),
            "50" to listOf("49", "51", "58", "82"),
            "51" to listOf("50", "52", "54"),
            "52" to listOf("51", "53", "55"),
            "53" to listOf("52", "56"),
            "54" to listOf("51", "56", "59"),
            "55" to listOf("52", "58", "60"),
            "56" to listOf("53", "54", "60"),
            "58" to listOf("48", "50", "55", "60"),
            "59" to listOf("54", "60"),
            "60" to listOf("55", "58", "59", "61", "69"),
            "61" to listOf("60", "62", "69"),
            "62" to listOf("61", "63", "67"),
            "63" to listOf("62", "64", "66"),
            "64" to listOf("63", "65", "68"),
            "65" to listOf("64", "66", "70", "78"),
            "66" to listOf("63", "65", "67"),
            "67" to listOf("62", "66", "70"),
            "68" to listOf("64", "71"),
            "69" to listOf("60", "61", "70"),
            "70" to listOf("65", "67", "69"),
            "71" to listOf("68", "72", "78"),
            "72" to listOf("71", "73", "77"),
            "73" to listOf("72", "74", "76"),
            "74" to listOf("73", "75"),
            "75" to listOf("74", "76"),
            "76" to listOf("73", "75", "77"),
            "77" to listOf("72", "76"),
            "78" to listOf("31", "65", "71"),
            "79" to listOf("14", "80"),
            "80" to listOf("79", "36"),
            "81" to listOf("33", "40"),
            "82" to listOf("31", "50")
        )


        // Set up button click listeners
        binding.findPathButton.setOnClickListener {
            val startNode = binding.mapView.getStartNodeId()
            val endNode = binding.mapView.getEndNodeId()
            if (startNode != null && endNode != null) {
                val path = findPathWithBFS(startNode, endNode)
                binding.mapView.setPath(path)
                displayPath(path)
            } else {
                binding.pathTextView.text = "Please select both start and end points."
            }
        }

        binding.resetButton.setOnClickListener {
            binding.mapView.resetSelection()
            binding.pathTextView.text = "Path will be displayed here"
        }
    }

    private fun findPathWithBFS(start: String, end: String): List<String> {
        val queue: Queue<String> = LinkedList()
        val visited = mutableSetOf<String>()
        val parentMap = mutableMapOf<String, String?>()

        queue.add(start)
        visited.add(start)
        parentMap[start] = null

        while (queue.isNotEmpty()) {
            val current = queue.poll()

            if (current == end) {
                break
            }

            val neighbors = graph[current] ?: emptyList()
            for (neighbor in neighbors) {
                if (neighbor !in visited) {
                    queue.add(neighbor)
                    visited.add(neighbor)
                    parentMap[neighbor] = current
                }
            }
        }

        // Reconstruct the path
        val path = mutableListOf<String>()
        var current: String? = end
        while (current != null) {
            path.add(0, current)
            current = parentMap[current]
        }

        return if (path.firstOrNull() == start) path else emptyList()
    }

    private fun displayPath(path: List<String>) {
        if (path.isEmpty()) {
            binding.pathTextView.text = "No path found between the selected locations."
            return
        }

        val nodeDescriptions = mapOf(
            "A" to "Jl. Pucang Anom & Jl. Kalibokor",
            "B" to "Jl. Kalibokor & Jl. Kalibokor Timur",
            "C" to "Jl. Kalibokor Timur & Jl. Manyar Air",
            "D" to "Jl. Kalibokor & Jl. Ngagel Jaya Utara",
            "E" to "Jl. Ngagel Jaya Utara & Jl. Ngagel Jaya Tengah",
            "F" to "Jl. Ngagel Jaya Tengah & Jl. Manyar Rejo",
            "G" to "Jl. Bratang Binangun & Jl. Ngagel Jaya Selatan",
            "H" to "Jl. Ngagel Jaya Selatan & Jl. Manyar Rejo",
            "I" to "Jl. Bratang Binangun & Jl. Krukah Binangun Timur",
            "J" to "Jl. Krukah Binangun Timur & Jl. Ngagel Jaya Selatan"
        )

        val pathDescription = path.map { node ->
            nodeDescriptions[node] ?: node
        }.joinToString(" -> ")
        binding.pathTextView.text = "Path: $pathDescription"
    }
}